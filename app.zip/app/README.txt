# XVX Browser

it's a very basic and minimal Browser that its creators don't track you
because we don't track anyone, the source code is open, and we didn't hide anything
that tracks people or anything like that.

-THE 1.8b UPDATE (AKA 'Kakudai origin') (W1.1b/A1.0f):

this update is to get rid of the temporary way for the AAM to work using a weird and modified version of the normal W1.1 and instead now it depends on the actual  W1.1b update which would be the base method and not temporary.

-THE new A1.0(Advanced Application Manager)(W1.1b):

this update is going to replace the XVX Browser installation manager
with an AAM(Advanced Application Manager) which is a very flexible
and useful way to install dependencies and requirements for a specific app

-THE 1.8 UPDATE (AKA 'Kakudai') or W1.1 FEATURES:

1-Extensions

2-extreme improvements and fixes with the search engine choose storing and reading

3-url bar search support search engine changing action

4-incognito mode homepage got the same amount of features as normal homepage

5-GUI changes

6-GUI items not showing when the window is opened expect when moving or resizing BUG has been fixed

7-new background(for default mode homepage)

-THE new W1.0(WeDu software base environment):

this update is very, very important for YOU
as a user because if we wanted to make any of our
under-support software into app version they would be huge
like the simple Xcceleratext program would be at least 350 or 400 mb
like it's just a text editor so if we made more software at future
without the new environment the sizes would be so unnecessarily large
and pain to download,store and mange.

so instead of all of that we made that the base environment of all apps
(which is nearly the same with little differences but because of each app got its
own environment that made them so large) turned into a one main environment
that all apps depend on that would make our programs much smaller for example:

**the previous version of XVX Browser was 950 MB**

**but this version is only 210 MB !!**

**and the installer is only 30MB !!**

-THE 1.7A1(first addon) UPDATE:

we made both history and bookmarks instead of the new items
are down(which the reverse for modern browsers ) we made them
that the new item are up(the same as other modern browsers

-THE 1.7 UPDATE (AKA 'gospel of balnoma'):

it's the same as 1.6 update but all the removed features came back(expect the documentation(it might not come back for long time)

plus we fixed many bugs

SOON THE UPDATE FEATURE WOULD GET A REAL SUPPORT SO THE NEXT UPDATES(AFTER 1.7)
WOULD BE FOR THE UPDATING SYSTEM AND YOU CAN GET THEM USING THE CURRENT UPDATE
FEATURE(WHICH ISN'T THAT COMPLETE) BUT IT WOULD BE USED TO UPDATE ITSELF UNTIL
IT WOULD REACH A HIGH STATE OF DEVELOPMENT THAT THE BROWSER CAN DEPEND ON IT FOR
UPDATING THE WHOLE THING.

-THE 1.6 UPDATE (WEIRDO):

WE DELETED BOTH 'profiles' & 'Incognito mode(IM)'

and we fixed the blur in the website titles, and we added two other new features:

1-changing background
2-changing search engine

-THE 1.5-SF UPDATE (server fixes):

finally we fixed the problem that made servers useless in XVX Browser after a very long time from the first
release but now it requires from you to write not only the port but the host number or computer id for example:

192.168.0.108

-THE 1.5-F UPDATE (fully fixed):

this is the same as the 1.5 BIG FIXES
but with the new documentation

-THE 1.5 UPDATE BIG FIXES:

WE MADE THIS UPDATE TO JUST SAVE OUR AND YOUR ASS
SEE THIS UPDATE IS IMPORTANT LIKE FREAKING IMPORTANT

NOTE: DON'T NEVER INSTALL 1.5 VERSION INSTEAD INSTALL THIS ONE
CUZ THIS VERSION FIXES BUGS THAT ARE VERY VERY BAD LIKE THE THE THIRD USER CAN NOT START AND THE IM DOESN'T WORK GREATLY AND

ANDDDDDDDD THE UPDATE FEATURE WASN'T WORKING
note: and with all of these serious stuff we made a very very small change that is too silly to say but it's changing this:

XVX Browser: incognito mode
to this: XVX Browser: incognito mode History

SO WE MADE THIS UPDATE TO FIX OF THESE PROBLEMS

-THE NEW 1.5 (AKA 'the skinakola update') UPDATE FEATURES-

NOTE:THIS IS UPDATE IS THE BIGGEST UPDATE EVER AT THE TIME THAT IT CAME IN (25/10/2024)
so with this update (the 1.5 update) we got:

1-profiles
2-incognito mode
3-updating system
4-new home page
5-new background
6-update to the cleaning system
7-OH I nearly forgot but we fixed the current username issue that in some computers the current user name is not the same as the current user path which caused some problems but we fixed it with this update

-THE NEW 1.4-AA(ALL DONE 'addon') UPDATE FEATURES-

this update is like an addon for the previous update which adds new cache delete system that allow to you to either
clear the default cache folder or a PSCF(previously specified cache folder) chosen by you and we add the new "burn"
feature that would do the same as clear(Both normal and PSCF cases) plus clearing history and bookmarks

-THE NEW 1.4-A(ALL DONE) UPDATE FEATURES-

this update would be the last update for the 1.4 series and we in it fix a lot of bugs and this update would come
with the first ever documentation for XVX Browser we fixed all the bug and even theme problems and bug and we
added even the check button so it wouldn't allow to you to save the new theme if you wrote nothing to prevent the
glitch of happening and prevent that it might be used as a way to turn to the default theme because it wouldn't
look the same and it has many problems and for some people when the made a theme the text color in buttons wasn't
the best and they have even like some tab using this bad unreadable text color so when they go to theme page
they change the text into more readable one all new page are using the old text but the old pages aren't
so you can just hover on the buttons in the old pages and you can see that the text is changing from the old to the new
and this is to just save and make the user old pages much more usable and this update would be the last
update for long period of time and it's been created for long time support and high stability.

-THE NEW 1.4-U(Ultra) UPDATE FEATURES-

we added to the browser some features which allow to you to make a local host server and it can handle two users in the server to talk between each other with very strong system which doesn't allow to anyone after the two
first users connection so any one after them can't join and even if they went out of the server they can't come
back they should open a new server and that is max level protection.

-THE NEW 1.4-N(new installation system) UPDATE FEATURES-

nearly the browser is the same but the app version of it the installer became much easier and better without like
two installer without even counting the one that you install it from our website or here but now it became much better.

-THE NEW 1.4 UPDATE FEATURES-

1-you can change buttons,text,background(buttons-holding-tab)
2-our first browser homepage
3-turn back things to normal(default) theme
4-the page settings finally got fixed, and now it's functioning normally
5-you can disable history so where ever you go you won't get recorded by the history
page or anything like that

6-zoom bar
7-page forever lock mode
8-other more complex things have being added
9-GUI fixes

-THE NEW 1.3 UPDATE FEATURES-

1-fixing bug and the title bar problem
2-better performance

-THE NEW 1.2 UPDATE FEATURES-

1-bookmarks
2-General Setting which contains two thing literal mode and another bookmarks setting
3-now you can delete a specific item in history and this feature even exists
in the new bookmarks page
4-show downloads folder
5-fix the old menu which hides itself when maximizing the window

-THE NEW 1.1 UPDATE FEATURES-

1-under the url bar there is the website title bar
2-the literal mode which it's by default False but when you
activate it when you write like google.com it would not open because
unlike when it's false it wouldn't correct it to https://google.com
and this mode only use is when you want to open a file or use
an url command like calculator:/
3-small changes and bug fixes

-THE 1.0 RELEASE CONTAINS-

1-history and deleting history
2-find in webpage
3-tab based (you can open multiple websites in multiple different tabs)
4-basic functions like reload, previous and forward
5-you can print the page
6-dev tools (Microsoft Edge devtools but don't worry
they are open source and safe, so microsoft can't track you)
7-showing the source code of the page
8-you can zoom in and out