import subprocess 
subprocess.Popen('C:/WeDu/Python312/python.exe main.py',creationflags=subprocess.CREATE_NO_WINDOW)